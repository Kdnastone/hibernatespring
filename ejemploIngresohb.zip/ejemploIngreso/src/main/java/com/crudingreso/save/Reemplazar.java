package com.crudingreso.save;


import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import ejemploIngreso.ejemploIngreso.Ingreso;

//Códigos CRUD:
//3) Este es el código para modificar o actualizar los datos en la base de datos:

public class Reemplazar {
    
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Configuración de Hibernate
            SessionFactory factory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Ingreso.class)
                    .buildSessionFactory();
            
            // Creación de la sesión
            Session session = factory.getCurrentSession();
             
            try {
                // Inicio de la transacción
                session.beginTransaction();

                // Solicitar al usuario que ingrese el ID del usuario que desea actualizar
                System.out.print("Ingrese el ID del usuario que desea actualizar: ");
                int especieId = scanner.nextInt();
                scanner.nextLine(); // Consumir el carácter de nueva línea restante

                // Obtener el usuario de la base de datos
                Ingreso ingreso = session.get(Ingreso.class, especieId);

                // Verificar si se encontró el usuario
                if (ingreso != null) {
                    // Solicitar al usuario que ingrese nuevamente los campos
                    System.out.print("Ingrese el grupo al que pertenece (Dep, Par, Ent, Prey, Host): ");
                    String newGrupo = scanner.nextLine();
                    System.out.print("Ingrese la ubicación del individuo (Suelo, Planta, Agua, SuPla): ");
                    String newUbicacion = scanner.nextLine();
                    System.out.print("Ingrese el nombre común del individuo: ");
                    String newNombrecomun = scanner.nextLine();
                    System.out.print("Ingrese el género al que pertenece: ");
                    String newGenero= scanner.nextLine();
                    System.out.print("Ingrese la especie al que pertenece: ");
                    String newEspecie= scanner.nextLine();

                    // Actualizar cada uno de los campos
                    ingreso.setGrupo(newGrupo);
                    ingreso.setUbicacion(newUbicacion);
                    ingreso.setNombreComun(newNombrecomun);
                    ingreso.setGenero(newGenero);
                    ingreso.setEspecie(newEspecie);

                    // Confirmar la transacción
                    session.getTransaction().commit();
                    System.out.println("Usuario actualizado exitosamente!");
                } else {
                    System.out.println("No se encontró un usuario con el ID proporcionado.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                factory.close();
            }
        }
    }
}


