package com.crudingreso.save;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.metamodel.StaticMetamodel;
import ejemploIngreso.ejemploIngreso.Ingreso;


@StaticMetamodel(Query.class)
@Entity
@Table

// Códigos CRUD:
// 1) Este es el código la consulta de datos en la base de datos:
public class ConsultaGeneral {
	
    public static void main(String[] args) {
    	// Configuración de Hibernate
        SessionFactory factory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Ingreso.class)
                .buildSessionFactory();

     // Creación de la sesión
        Session session = factory.getCurrentSession();

        try {
        	// Comienza la transacción
            session.beginTransaction();

            // Crear la consulta HQL para seleccionar todos los registros de la tabla Ingreso
            String hql = "FROM Ingreso";
            org.hibernate.query.Query<Ingreso> query = session.createQuery(hql, Ingreso.class);

            // Ejecutar la consulta y obtener los resultados
            java.util.List<Ingreso> resultados = query.list();
            System.out.println("\nConsulta general");
            for (Ingreso u : resultados) {
                System.out.println(u);
            }
            //Finalización de la transacción y mensaje de finalización del proceso
            session.getTransaction().commit();
            System.out.println("Proceso finalizado exitosamente!");

        } finally {
        	// Cerrar la sesión y el factory
            factory.close();
        }
    }
}

