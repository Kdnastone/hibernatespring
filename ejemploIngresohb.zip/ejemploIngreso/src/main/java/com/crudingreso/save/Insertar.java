package com.crudingreso.save;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import ejemploIngreso.ejemploIngreso.Ingreso;
import java.util.Scanner;


//Códigos CRUD:
//2) Este es el código para agregar datos a la base de datos:
public class Insertar {
    
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Configuración de Hibernate
            SessionFactory factory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Ingreso.class)
                    .buildSessionFactory();
            
            // Creación de la sesión
            Session session = factory.getCurrentSession();
            
            try {
                // Comienza la transacción
                session.beginTransaction();
                
                // Solicitar al usuario los datos de ingreso
                System.out.println("Ingrese el grupo al que pertenece (Dep, Par, Ent, Prey, Host): ");
                String grupo = scanner.nextLine();
                System.out.println("Ingrese la ubicación del individuo (Suelo, Planta, Agua, Similares): ");
                String ubicacion = scanner.nextLine();
                System.out.println("Ingrese el nombre común del individuo: ");
                String nombreComun = scanner.nextLine();
                System.out.println("Ingrese el género al que pertenece: ");
                String genero = scanner.nextLine();
                System.out.println("Ingrese la especie al que pertenece: ");
                String especie = scanner.nextLine();
                
                // Crear un nuevo objeto Ingreso con los datos proporcionados por el usuario
                Ingreso ingreso = new Ingreso(grupo, ubicacion, nombreComun, genero, especie);
                
                // Guardar el objeto en la base de datos
                session.persist(ingreso);
                
                // Commit de la transacción
                session.getTransaction().commit();
                
                System.out.println("Registro exitosamente almacenado!");
            } catch (HibernateException e) {
                // Manejo de excepciones de Hibernate
                if (session.getTransaction() != null) {
                    session.getTransaction().rollback();
                }
                e.printStackTrace();
            } finally {
                // Cerrar la sesión y el factory
                factory.close();
            }
        }
    }
}
