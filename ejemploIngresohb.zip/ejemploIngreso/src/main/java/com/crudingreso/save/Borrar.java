package com.crudingreso.save;

import org.hibernate.cfg.Configuration;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import ejemploIngreso.ejemploIngreso.Ingreso;

//Códigos CRUD:
//4) Este es el código para borrar los datos en la base de datos:

public class Borrar {
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Configuración de Hibernate
            SessionFactory factory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Ingreso.class)
                    .buildSessionFactory();
            
            // Creación de la sesión
            Session session = factory.getCurrentSession();

        try {
            // Inicio de la transacción
            session.beginTransaction();

            // Creación de un objeto Scanner para leer la entrada del usuario
            try (Scanner scanner1 = new Scanner(System.in)) {

                // Solicitar al usuario que ingrese el ID del registro que desea eliminar
                System.out.print("Ingrese el ID del registro que desea eliminar: ");
                int especieId = scanner1.nextInt();

                // Obtener el registro correspondiente de la base de datos
                Ingreso ingreso = session.get(Ingreso.class, especieId);

                // Verificar si se encontró el registro
                if (ingreso != null) {
                    // Eliminar el registro de la base de datos
                    session.remove(ingreso);

                    // Confirmar la transacción
                    session.getTransaction().commit();
                    System.out.println("Registro eliminado exitosamente!");
                } else {
                    System.out.println("No se encontró un registro con el ID proporcionado.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Cerrar la sesión y el factory
            session.close();
            factory.close();
        }
    }
   }
  }

