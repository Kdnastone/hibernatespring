package com.crudingreso.save;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.metamodel.StaticMetamodel;
import ejemploIngreso.ejemploIngreso.Ingreso;
import java.util.Scanner;

@StaticMetamodel(Query.class)
@Entity
@Table
public class Consultaporcampo{

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Configuración de Hibernate
            SessionFactory factory = new Configuration()
                    .configure("hibernate.cfg.xml")
                    .addAnnotatedClass(Ingreso.class)
                    .buildSessionFactory();
            
            // Creación de la sesión
            Session session = factory.getCurrentSession();

        try {
            session.beginTransaction();

            try (Scanner scanner1 = new Scanner(System.in)) {
				System.out.println("¿Por cuál filtro deseas realizar la búsqueda? (especieId, grupo, ubicacion, nombreComun, genero, especie): ");
				String filtro = scanner1.nextLine();

				System.out.println("Ingresa el valor del filtro: ");
				String valorFiltro = scanner1.nextLine();

				// Crear la consulta HQL con el filtro deseado
				String hql = "FROM Ingreso WHERE " + filtro + " = :valor";
				org.hibernate.query.Query<Ingreso> query = session.createQuery(hql, Ingreso.class);
				query.setParameter("valor", valorFiltro);

				// Ejecutar la consulta y obtener los resultados
				java.util.List<Ingreso> resultados = query.list();
				System.out.println("\nResultados de la consulta con filtro " + filtro + " = " + valorFiltro);
				for (Ingreso u : resultados) {
				    System.out.println(u);
				}
			}

            session.getTransaction().commit();
            System.out.println("Proceso finalizado exitosamente!");

        } finally {
            factory.close();
        }
    }
  }
}
