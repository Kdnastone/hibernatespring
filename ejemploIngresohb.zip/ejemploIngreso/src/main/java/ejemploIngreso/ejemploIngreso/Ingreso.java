package ejemploIngreso.ejemploIngreso;

import org.springframework.stereotype.Repository;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;

// Generated 16/03/2024, 8:19:28 p. m. by Hibernate Tools 6.3.1.Final

@Entity
@Table(name = "ingreso")
@Repository
public class Ingreso {

	private Integer especieId;
	private String grupo;
	private String ubicacion;
	private String nombreComun;
	private String genero;
	private String especie;

	public Ingreso() {
	}

	public Ingreso(String grupo, String ubicacion, String nombreComun, String genero, String especie) {
		this.grupo = grupo;
		this.ubicacion = ubicacion;
		this.nombreComun = nombreComun;
		this.genero = genero;
		this.especie = especie;
	}

	public Integer getEspecieId() {
		return this.especieId;
	}
	public Ingreso(Integer especieId, String grupo, String ubicacion, String nombreComun, String genero,
			String especie) {
		super();
		this.especieId = especieId;
		this.grupo = grupo;
		this.ubicacion = ubicacion;
		this.nombreComun = nombreComun;
		this.genero = genero;
		this.especie = especie;
	}

	@Override
	public String toString() {
		return "Ingreso [especieId=" + especieId + ", grupo=" + grupo + ", ubicacion=" + ubicacion + ", nombreComun="
				+ nombreComun + ", genero=" + genero + ", especie=" + especie + "]";
	}

	public void setEspecieId(Integer especieId) {
		this.especieId = especieId;
	}

	public String getGrupo() {
		return this.grupo;
	}

	public void setGrupo(String grupo) {
		this.grupo = grupo;
	}

	public String getUbicacion() {
		return this.ubicacion;
	}

	public void setUbicacion(String ubicacion) {
		this.ubicacion = ubicacion;
	}

	public String getNombreComun() {
		return this.nombreComun;
	}

	public void setNombreComun(String nombreComun) {
		this.nombreComun = nombreComun;
	}

	public String getGenero() {
		return this.genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getEspecie() {
		return this.especie;
	}

	public void setEspecie(String especie) {
		this.especie = especie;
	}

}